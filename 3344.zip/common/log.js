

function log_in(){
	

	alert('ter');
	//alert(PASS_sg);
	

}